import { Link, useNavigate } from "react-router-dom";
import "../App.css";

function Dashboard() {
  const name = localStorage.getItem("name") || "User";
  const navigate = useNavigate();

  const logout = () => {
    localStorage.clear();
    navigate("/");
  };

  return (
    <div className="dashboard-page">
      <div className="dashboard-card">
        <div className="brand">
          <div className="heart-icon">♥</div>
          <h1>HeartAssist</h1>
        </div>

        <div className="line"></div>

        <h2>Welcome, {name}</h2>

        <p className="subtitle">
          AI-based ECG + Echo heart condition analysis system.
        </p>

        <div className="action-row">
          <Link to="/upload" className="main-action">
            <span className="circle-icon">☁</span>
            Upload New Analysis
          </Link>

          <Link to="/history" className="main-action">
            <span className="circle-icon">▤</span>
            View Past Reports
          </Link>
        </div>

        <button className="logout-action" onClick={logout}>
          <span>↪</span>
          Logout
        </button>
      </div>
    </div>
  );
}

export default Dashboard;