import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import API from "../api";

function History() {
  const [reports, setReports] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const userId = localStorage.getItem("user_id");
    API.get(`/reports/${userId}`).then((res) => setReports(res.data));
  }, []);

  return (
    <div className="page">
      <div className="card">
        <button className="back-btn" onClick={() => navigate(-1)}>← Back</button>

        <h1>Past Reports</h1>

        {reports.length === 0 && <p>No reports yet.</p>}

        {reports.map((report) => (
          <div className="report-card" key={report.id}>
            <h3>Report #{report.id}</h3>
            <p><b>Risk:</b> {report.risk_level}</p>
            <p><b>Date:</b> {report.created_at}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default History;