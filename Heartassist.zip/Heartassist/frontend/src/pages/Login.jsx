import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import API from "../api";

function Login() {
  const [form, setForm] = useState({
    email: "",
    password: "",
  });

  const navigate = useNavigate();

  const login = async () => {
    try {
      const res = await API.post("/login", form);

      if (res.data.user_id) {
        localStorage.setItem("user_id", res.data.user_id);
        localStorage.setItem("name", res.data.name);

        navigate("/dashboard");
      } else {
        alert(res.data.error);
      }
    } catch (err) {
      alert("Login failed");
    }
  };

  return (
    <div className="page">
      <div className="card">

        <h1>HeartAssist Login</h1>

        <input
          placeholder="Email"
          onChange={(e) =>
            setForm({ ...form, email: e.target.value })
          }
        />

        <input
          type="password"
          placeholder="Password"
          onChange={(e) =>
            setForm({ ...form, password: e.target.value })
          }
        />

        <button onClick={login}>
          Login
        </button>

        <p>
          No account? <Link to="/signup">Signup</Link>
        </p>

      </div>
    </div>
  );
}

export default Login;