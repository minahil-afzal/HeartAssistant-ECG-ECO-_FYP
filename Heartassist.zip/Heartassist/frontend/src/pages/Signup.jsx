import { useState } from "react";
import { useNavigate } from "react-router-dom";
import API from "../api";

function Signup() {
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const navigate = useNavigate();

  const signup = async () => {
    const res = await API.post("/signup", form);
    alert(res.data.message || res.data.error);
    if (res.data.user_id) navigate("/");
  };

  return (
    <div>
      <h1>Signup</h1>

      <input placeholder="Name" onChange={(e) => setForm({ ...form, name: e.target.value })} />
      <input placeholder="Email" onChange={(e) => setForm({ ...form, email: e.target.value })} />
      <input placeholder="Password" type="password" onChange={(e) => setForm({ ...form, password: e.target.value })} />

      <button onClick={signup}>Signup</button>
    </div>
  );
}

export default Signup;