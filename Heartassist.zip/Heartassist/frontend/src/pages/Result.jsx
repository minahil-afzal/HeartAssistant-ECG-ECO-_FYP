import { useNavigate } from "react-router-dom";

function Result() {
  const navigate = useNavigate();
  const result = JSON.parse(localStorage.getItem("latest_result"));

  if (!result) return <h2>No result found</h2>;

  return (
    <div className="page">
      <div className="card">
        <button className="back-btn" onClick={() => navigate(-1)}>← Back</button>

        <h1>Analysis Result</h1>

        <p className="badge">Risk Level: {result.fusion_result.risk_level}</p>

        <div className="report-card">
          <h2>Fusion Results</h2>
          <p><b>EF Value:</b> {result.fusion_result.EF}%</p>
          <p><b>ECG Findings:</b> {result.fusion_result.ecg_findings.join(", ")}</p>
        </div>

        <div className="report-card">
          <h2>AI Explanation</h2>
          <p>{result.llm_explanation}</p>
        </div>

        <button onClick={() => navigate("/history")}>View History</button>
        <button onClick={() => navigate("/dashboard")}>Dashboard</button>
      </div>
    </div>
  );
}

export default Result;