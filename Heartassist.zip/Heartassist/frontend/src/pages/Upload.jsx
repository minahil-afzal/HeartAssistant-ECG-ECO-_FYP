import { useState } from "react";
import { useNavigate } from "react-router-dom";
import API from "../api";

function Upload() {
  const [ecgFile, setEcgFile] = useState(null);
  const [echoFile, setEchoFile] = useState(null);
  const [symptoms, setSymptoms] = useState([]);
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate();
  const symptomOptions = ["Chest Pain", "Shortness of Breath", "Fatigue", "Palpitations"];

  const toggleSymptom = (symptom) => {
    setSymptoms(
      symptoms.includes(symptom)
        ? symptoms.filter((s) => s !== symptom)
        : [...symptoms, symptom]
    );
  };

  const analyze = async () => {
    if (!ecgFile || !echoFile) {
      alert("Please upload ECG and Echo files");
      return;
    }

    setLoading(true);

    const formData = new FormData();
    formData.append("user_id", localStorage.getItem("user_id"));
    formData.append("ecg_file", ecgFile);
    formData.append("echo_file", echoFile);
    formData.append("symptoms", symptoms.join(","));

    const res = await API.post("/analyze", formData);
    localStorage.setItem("latest_result", JSON.stringify(res.data));

    setLoading(false);
    navigate("/result");
  };

  return (
    <div className="page">
      <div className="card">
        <button className="back-btn" onClick={() => navigate(-1)}>← Back</button>

        <h1>Upload Analysis</h1>

        <label>ECG File (.csv / .npy)</label>
        <input type="file" accept=".csv,.npy" onChange={(e) => setEcgFile(e.target.files[0])} />

        <label>Echo Video (.mp4)</label>
        <input type="file" accept=".mp4" onChange={(e) => setEchoFile(e.target.files[0])} />

        <h3>Symptoms</h3>

        {symptomOptions.map((symptom) => (
        <label className="symptom-item" key={symptom}>
            <input
            type="checkbox"
            onChange={() => toggleSymptom(symptom)}
            />
            <span>{symptom}</span>
        </label>
        ))}

        <button onClick={analyze}>
        Analyze Heart Condition
        </button>

        {loading && (
          <div className="loading">
            <p>Running ECG Analysis...</p>
            <p>Running Echo Analysis...</p>
            <p>Generating Clinical Explanation...</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default Upload;